//
//  RegistrationViewController.swift
//  afterMovieApp
//  Created by Karanjot Singh
/* Members: Karanjot Singh
*/



import UIKit
class RegistrationViewController: UIViewController {

   
    @IBOutlet weak var UserEmailTxt: UITextField!
    @IBOutlet weak var UserPasswordTxt: UITextField!
    @IBOutlet weak var UserConfirmPass: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func cancelBtn(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    // When button is clicked
    @IBAction func registerButton(_ sender: Any) {
      
        let userEmail = UserEmailTxt.text;
        let userPassword = UserPasswordTxt.text;
        let confPassword = UserConfirmPass.text;
        
        //Check if the text fields are empty
        if((userEmail?.isEmpty)! || (userPassword?.isEmpty)! || (confPassword?.isEmpty)!){
            
            displayAlert(userMessage: "Please fill out all text fields.");
            return;
        }
        
        // Check to see if the passwords match
        if(userPassword != confPassword){
            
            displayAlert(userMessage: "Passwords do not match.");
            return;
        }
        
        //Storing the information
        
        UserDefaults.standard.set(userEmail, forKey:"userEmail");
        UserDefaults.standard.set(userPassword, forKey:"userPassword");
        UserDefaults.standard.synchronize();
        
        
        //Display alerts
        let alert = UIAlertController(title:"Alert", message:"Registration Success.", preferredStyle: UIAlertControllerStyle.alert);
        
        let alerting = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default){
            action in self.dismiss(animated: true, completion: nil)
        }
        
        alert.addAction(alerting);
        
        self.present(alert, animated: true,completion: nil)
    }
    
    
    // Alert function
    func displayAlert(userMessage:String){
        
        let alert = UIAlertController(title:"Alert", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let alerting = UIAlertAction(title: "Ok", style:UIAlertActionStyle.default, handler:nil);
        
        alert.addAction(alerting);
        
        self.present(alert, animated:true, completion:nil);
        
        
        
    }

}
