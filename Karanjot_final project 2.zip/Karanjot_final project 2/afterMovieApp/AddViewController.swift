//
//  AddViewController.swift
//  afterMovieApp
//  Created by Karanjot Singh
/* Members: Karanjot Singh
 */


import SQLite3
import UIKit


class AddViewController: UIViewController {

    var db:OpaquePointer?
    
    // When Buttons are clicked the textfield will change text accordingly
    @IBAction func AvengersBtn(_ sender: UIButton) {
        reviewText.text = "Avengers"
    }
    
    @IBAction func LaLaLandBtn(_ sender: UIButton) {
        reviewText.text = "La La Land"
    }
    
    @IBAction func MrBeanBtn(_ sender: UIButton) {
        reviewText.text = "Mr.Bean Holiday"
    }
    
    @IBAction func GetOutBtn(_ sender: UIButton) {
        reviewText.text = "Get Out"
    }
    
    @IBAction func PokemonBtn(_ sender: UIButton) {
        reviewText.text = "Pokemon"
    }
    
    
    @IBOutlet weak var reviewText: UITextField!
    @IBOutlet weak var ratingText: UITextView!
    @IBAction func addReview(_ sender: Any) {
        
        let review = reviewText.text!
        let rating = ratingText.text!
        
       
        
     //Checking if text fields are empty
        if(review.isEmpty){
            displayAlert(userMessage: "Please fill out all text fields.");
            return;
        }
        if(rating.isEmpty){
            displayAlert(userMessage: "Please fill out all text fields.");
            return;
        }
        
       
        

        //Inserting info to the database
        let insert = "INSERT INTO Reviews(review, rating) VALUES (?, ?)"
        var stmt:OpaquePointer?
        
        if sqlite3_prepare(db, insert, -1, &stmt, nil) != SQLITE_OK {
            let err = String(cString: sqlite3_errmsg(db))
            print("error preparing statement: \(err)")
            return
            
        }
        if sqlite3_bind_text(stmt, 2, review, -1, nil) != SQLITE_OK {
            let err = String(cString: sqlite3_errmsg(db))
            print("error biding review: \(err)")
            return
            
        }
        if sqlite3_bind_text(stmt, 1, rating, -1, nil) != SQLITE_OK {
            let err = String(cString: sqlite3_errmsg(db))
            print("error biding review: \(err)")
            return
            
        }
        
        if sqlite3_step(stmt) != SQLITE_DONE{
            let err = String(cString: sqlite3_errmsg(db))
            print("error executing insert: \(err)")
            return
    }
        
        func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
      // function for alerts
    };func displayAlert(userMessage:String){
        
        let alert = UIAlertController(title:"Alert", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let alerting = UIAlertAction(title: "Ok", style:UIAlertActionStyle.default, handler:nil);
        
        alert.addAction(alerting);
        
        self.present(alert, animated:true, completion:nil);
        
        
        
    }
}
