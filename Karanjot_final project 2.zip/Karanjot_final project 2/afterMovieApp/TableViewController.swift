//
//  TableViewController.swift
//  afterMovieApp
//  Created by Karanjot Singh
/* Members: Karanjot Singh
 */


import UIKit
import SQLite3

class TableViewController: UITableViewController {

    
    var db:OpaquePointer?
    var reviews = [Review]()
    
    
    func readValues(){
        reviews.removeAll()
        let q = "SELECT * FROM Reviews"
        var stmt:OpaquePointer?
        if sqlite3_prepare(db, q, -1, &stmt, nil)  != SQLITE_OK{
            let err = String(cString: sqlite3_errmsg(db))
            print("error preparing statement: \(err)")
            return
            
        }
        while sqlite3_step(stmt) == SQLITE_ROW{
            let id = Int(sqlite3_column_int(stmt, 0))
            let review = String(cString: sqlite3_column_text(stmt,2))
            let rating = String(cString:sqlite3_column_text(stmt, 1))
            
            let r = Review(id: id, review: review, rating:rating)
            reviews.append(r)
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Creating the database
        let file = try!
            FileManager.default.url(for: .documentDirectory , in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("database7.db")
        
        if sqlite3_open(file.path, &db) != SQLITE_OK{
            
            print("Error opening database")
        }else{
            let create =
            "CREATE TABLE IF NOT EXISTS Reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, rating TEXT, review TEXT)"
            
            if sqlite3_exec(db, create,nil,nil,nil) != SQLITE_OK{
                let err = String(cString: sqlite3_errmsg(db))
                print("error creating db: \(err)")
            }
        }
       
        
    } 
     //Adding to the database
    override func viewWillAppear(_ animated: Bool) {
        readValues()
        tableView.reloadData()
    }
    func addSample(){
        let insert = "INSERT INTO Reviews(review, rating) VALUES (?, ?)"
        var stmt:OpaquePointer?
        for i in 1...10{
            
            if sqlite3_prepare(db, insert, -1, &stmt, nil) !=
                SQLITE_OK {
                let err = String(cString: sqlite3_errmsg(db))
                print("error preparing statement: \(err)")
                return
            
            }
            if sqlite3_bind_text(stmt, 2, "Review\(i)", -1, nil) !=
                SQLITE_OK {
                let err = String(cString: sqlite3_errmsg(db))
                print("error biding review: \(err)")
                return
                
            }
           
        if sqlite3_bind_text(stmt, 1, "Rating\(i)", -1, nil) !=
            SQLITE_OK {
            let err = String(cString: sqlite3_errmsg(db))
            print("error biding review: \(err)")
            return
            
        }
            
            if sqlite3_step(stmt) != SQLITE_DONE{
                let err = String(cString: sqlite3_errmsg(db))
                print("error executing insert: \(err)")
                return
            
            }
        }
       
        
    }
    //Deleting Rows
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete
        {
            
            reviews.remove(at: indexPath.row)
            tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
            tableView.reloadData()
            
            
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return reviews.count
    }

    //reusable identfier
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...
       cell.textLabel?.text = reviews[indexPath.row].review
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "show") {
            let dc = segue.destination as! ViewController
            dc.review = reviews[tableView.indexPathForSelectedRow!.row]
        }else if segue.identifier == "add"{
            let dc = segue.destination as! AddViewController
            dc.db = db
        }
    }
    

}
