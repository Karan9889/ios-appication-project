//
//  Review.swift
//  afterMovieApp
//  Created by Karanjot Singh
/* Members: Karanjot Singh
 */


import Foundation
class Review{
    
    var id:Int
    var review:String
    var rating:String
    
    init(id:Int, review:String, rating:String) {
        self.id = id
        self.review = review
        self.rating = rating
    }
    
}


