//
//  ViewController.swift
//  afterMovieApp
//  Created by Karanjot Singh
/* Members: Karanjot Singh
 */

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var idText: UILabel!
    
    @IBOutlet weak var reviewText: UILabel!
    @IBOutlet weak var ratingText: UILabel!
    @IBOutlet weak var DateText: UILabel!
    var review:Review?
    
    var timer = Timer()
    
    override func viewDidAppear(_ animated: Bool) {
        timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(ViewController.updateClock), userInfo: nil, repeats: true)
    }
    
    
    /*
     Clock function  Found on the following link below
 https://www.youtube.com/watch?v=K__p35h93hk
 */
    @objc func updateClock(){
        let timeFormatter = DateFormatter()
        timeFormatter.timeStyle = .medium
        timeFormatter.dateStyle = .medium
        let timeString = "\(timeFormatter.string(from: Date() as Date))"
        DateText.text = String(timeString)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Alligning the labels with the corrent info from the database
        
        if let r = review {
            idText.text = "\(r.id)"
            reviewText.text = r.review
            ratingText.text = r.rating
            
            
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

