 //
//  LoginViewController.swift
//  afterMovieApp
//  Created by Karanjot Singh
/* Members: Karanjot Singh
*/

import UIKit
class LoginViewController: UIViewController {

    @IBOutlet weak var userEmailTxt: UITextField!
    @IBOutlet weak var userPasswordTxt: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    // Button click + Grab Info from local db to see if email and password match
    @IBAction func LoginButton(_ sender: Any) {
        
        let userEmail = userEmailTxt.text;
        let userPassword = userPasswordTxt.text;
        
        let userEmailData = UserDefaults.standard.string(forKey: "userEmail");
        
       let userPasswordData = UserDefaults.standard.string(forKey: "userPassword");
        
        
        //Check to see if the text fields are empty
        if((userEmail?.isEmpty)! || (userPassword?.isEmpty)!){
                displayAlert(userMessage: "Email or Password field is empty.");
        }
        
        // Check to see if Email and Password matches
        if(userEmailData == userEmail){
            
            if(userPasswordData == userPassword){
                
                
            }else {
                displayAlert(userMessage: "Invalid Login.");
            }
                
        }else {
            displayAlert(userMessage: "Invalid Login.");
        }
        
        
    }
    
    //Display Alert Function
    func displayAlert(userMessage:String){
        
        let alert = UIAlertController(title:"Alert", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let alerting = UIAlertAction(title: "Ok", style:UIAlertActionStyle.default, handler:nil);
        
        alert.addAction(alerting);
        
        self.present(alert, animated:true, completion:nil);
    }

}
